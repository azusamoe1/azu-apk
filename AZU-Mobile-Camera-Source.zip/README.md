# AZU Mobile Camera — starter source

This is the initial source scaffold for an Android phone camera + Windows companion.

## What is included
- Android Studio Kotlin project using CameraX.
- Android app starts a local HTTP server while its screen is open.
- PC companion prototype (.NET 8 WinForms) sends a capture request and downloads the JPEG.
- Local Wi-Fi pairing by IP address and one-time pairing token.

## Important status
This is **source code**, not a compiled APK or a finished Windows virtual-camera driver.
The current PC prototype receives still photos. Making the phone appear as a selectable
camera in *every* Windows application requires a separate virtual-camera implementation
and OS-specific validation/signing. That layer is deliberately not represented as finished.

## Build Android APK
1. Install Android Studio (current stable) and Android SDK.
2. Open `android/` as a project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the debug APK on the Android phone.
6. Keep the app open, grant camera permission, and note the displayed IP and token.

## Build Windows prototype
Install the .NET 8 SDK and run:
`dotnet run --project windows/AzuCameraBridge`

The Windows prototype targets x86 and can run under 32-bit Windows. A separate x64 build
can be produced for 64-bit Windows. The future virtual-camera component must be built and
tested separately for each supported Windows architecture/version.

## Network
Both devices must be on the same Wi-Fi/LAN. Allow the app through Windows Firewall on
private networks only. Do not expose the phone's local capture server to the public internet.
