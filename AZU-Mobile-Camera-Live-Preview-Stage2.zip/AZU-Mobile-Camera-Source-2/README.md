# AZU Mobile Camera — Live Preview Stage 2 (Selectable Profiles)

## What this build adds
- QR pairing between the Android phone and Windows bridge over the same Wi-Fi network.
- Continuous camera frames from Android CameraX to Windows using an authenticated WebSocket.
- Android controls for 640×480, 1280×720 HD, and 1920×1080 Full HD.
- Requested frame-rate choices of 10, 30, and 60 FPS, with camera fallback if the requested mode cannot be bound.
- Windows live preview in the AZU Camera Bridge window.
- Existing PC-requested still-photo capture is retained.

## Important scope limitation
This is **Stage 2: selectable live-video profiles and Windows preview only**. It does **not** yet create a Windows camera device. Therefore, apps such as Teams, Zoom, browsers, or the BIS portal will **not** see `AZU Mobile Camera` in their camera dropdown yet. That requires a separate Windows virtual-camera driver/component and OS-specific installation packages. No XP–Windows 11 compatibility claim is made by this preview build.

## Android build
Open `android/` in Android Studio, or use the repository's Gradle workflow. Build with JDK 17 and a compatible Android Gradle Plugin/Gradle wrapper. The app requires Android API 26 or later and camera permission.

## Windows build
Install the .NET 8 SDK on Windows and run:

```powershell
dotnet restore windows/AzuCameraBridge/AzuCameraBridge.csproj
dotnet run --project windows/AzuCameraBridge/AzuCameraBridge.csproj
```

The current Windows project targets x86. A separate x64 build/package still needs to be prepared and tested.

## Use
1. Connect the phone and Windows PC to the same trusted Wi-Fi network.
2. Start AZU Camera Bridge on Windows and allow it through Windows Firewall on a private network.
3. Open AZU Mobile Camera on Android and grant camera permission.
4. Scan the QR code displayed by the Windows app.
5. The Windows window should display a live preview. Keep the Android app in the foreground.
6. The existing **Capture photo** button still requests and saves a full-resolution still image under `Pictures\\AZU Mobile Camera`.

## Current stream settings
- Selectable analysis targets: 640×480, 1280×720, and 1920×1080.
- Selectable requested frame rates: 10, 30, and 60 FPS.
- CameraX is asked to use the selected fixed frame-rate range; if the phone rejects that mode, the app retries with the camera default. Outgoing frames are also rate-limited to the selected FPS.
- JPEG quality: 65.
- Frames are skipped when the WebSocket send queue grows beyond 512 KiB, to avoid unbounded buffering.
- Each WebSocket connection is authenticated using the pairing token.

## Performance notes
60 FPS at 1080p is demanding. The actual delivered frame rate depends on the phone camera supported stream combinations, CPU/GPU performance, thermal state, and Wi-Fi throughput. If the requested camera mode is unsupported, the app falls back to the camera default frame rate. Changing a profile rebinds the camera and briefly interrupts the stream.

## Next development stage
Implement and validate the Windows virtual-camera component so the phone feed appears as a selectable camera device in ordinary Windows applications. That is a separate driver/API task; the preview code here is not a virtual webcam driver.

## Security and network
This prototype uses plain HTTP/WebSocket on the local network. Pair only on a trusted private Wi-Fi network. Do not expose port 8765 to the public internet. Production use will need stronger transport security and a hardened pairing lifecycle.
