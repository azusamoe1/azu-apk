package com.azu.mobilecamera

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.util.Size
import android.util.Range
import android.widget.TextView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var resolutionSpinner: Spinner
    private lateinit var fpsSpinner: Spinner
    private var selectedSize = Size(1280, 720)
    @Volatile private var selectedFps = 30
    @Volatile private var cameraReady = false
    private var imageCapture: ImageCapture? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS).readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS).build()
    private val paired = AtomicBoolean(false)
    private val pairingInProgress = AtomicBoolean(false)
    private val captureBusy = AtomicBoolean(false)
    private val lastFrameAt = AtomicLong(0)
    @Volatile private var pcBase = ""
    @Volatile private var token = ""
    @Volatile private var videoSocket: WebSocket? = null
    private val scanner = BarcodeScanning.getClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        resolutionSpinner = findViewById(R.id.resolutionSpinner)
        fpsSpinner = findViewById(R.id.fpsSpinner)
        val resolutionLabels = listOf("640 × 480", "1280 × 720 HD", "1920 × 1080 Full HD")
        resolutionSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, resolutionLabels)
        fpsSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("10 FPS", "30 FPS", "60 FPS"))
        resolutionSpinner.setSelection(1, false)
        fpsSpinner.setSelection(1, false)
        val profileChanged = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedSize = when (resolutionSpinner.selectedItemPosition) {
                    0 -> Size(640, 480)
                    2 -> Size(1920, 1080)
                    else -> Size(1280, 720)
                }
                selectedFps = when (fpsSpinner.selectedItemPosition) {
                    0 -> 10
                    2 -> 60
                    else -> 30
                }
                if (cameraReady) startCamera()
                updateProfileText()
            }
        }
        resolutionSpinner.onItemSelectedListener = profileChanged
        fpsSpinner.onItemSelectedListener = profileChanged
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 100)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else status.text = "Camera permission is required."
    }

    private fun updateProfileText() {
        val size = selectedSize
        details.text = "Selected: ${size.width}×${size.height} at $selectedFps FPS. Actual rate depends on phone camera support and Wi-Fi."
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            provider.unbindAll()
            val targetSize = selectedSize
            val targetFps = selectedFps

            fun buildAndBind(requestFps: Boolean) {
                val previewBuilder = Preview.Builder().setTargetResolution(targetSize)
                val analysisBuilder = ImageAnalysis.Builder()
                    .setTargetResolution(targetSize)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                if (requestFps) {
                    val range = Range(targetFps, targetFps)
                    previewBuilder.setTargetFrameRate(range)
                    analysisBuilder.setTargetFrameRate(range)
                }
                val previewUseCase = previewBuilder.build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                val analysis = analysisBuilder.build()
                analysis.setAnalyzer(cameraExecutor) { image ->
                    if (paired.get()) streamFrame(image) else scanForPairing(image)
                }
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA,
                    previewUseCase, imageCapture, analysis)
            }

            try {
                try {
                    buildAndBind(true)
                    cameraReady = true
                    status.text = "Camera ready — scan the dynamic QR code on your PC"
                    updateProfileText()
                } catch (fpsError: Exception) {
                    provider.unbindAll()
                    buildAndBind(false)
                    cameraReady = true
                    status.text = "Camera ready — requested FPS mode unavailable; using camera default"
                    updateProfileText()
                }
            } catch (e: Exception) {
                cameraReady = false
                status.text = "Camera profile unavailable: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scanForPairing(proxy: ImageProxy) {
        var bitmap: Bitmap? = null
        try {
            bitmap = rgbaToBitmap(proxy)
            val rotated = rotateBitmap(bitmap, proxy.imageInfo.rotationDegrees)
            if (rotated !== bitmap) bitmap.recycle()
            bitmap = rotated
            scanner.process(InputImage.fromBitmap(rotated, 0))
                .addOnSuccessListener { codes ->
                    if (!paired.get()) {
                        val raw = codes.firstOrNull {
                            it.format == Barcode.FORMAT_QR_CODE && !it.rawValue.isNullOrBlank()
                        }?.rawValue
                        raw?.let { acceptQr(it) }
                    }
                }
                .addOnFailureListener { }
                .addOnCompleteListener {
                    bitmap?.recycle()
                    proxy.close()
                }
        } catch (_: Exception) {
            bitmap?.recycle()
            proxy.close()
        }
    }

    @Synchronized private fun acceptQr(raw: String) {
        if (paired.get() || !pairingInProgress.compareAndSet(false, true)) return
        try {
            val data = JSONObject(raw)
            val base = data.getString("url").trimEnd('/')
            val key = data.getString("token")
            require(base.startsWith("http://") && key.isNotBlank())
            pcBase = base
            token = key
            networkExecutor.execute {
                try {
                    val request = Request.Builder().url("$base/pair")
                        .post(JSONObject().put("token", key).put("device", android.os.Build.MODEL)
                            .toString().toRequestBody("application/json".toMediaType())).build()
                    http.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) throw IllegalStateException("PC rejected pairing (${response.code})")
                    }
                    paired.set(true)
                    openVideoSocket()
                    runOnUiThread {
                        status.text = "Connected — starting live video"
                        details.text = "Live preview streams to your Windows PC over Wi-Fi. Keep this app open."
                    }
                    Thread({ pollForCapture() }, "AZU-photo-poll").start()
                } catch (e: Exception) {
                    pairingInProgress.set(false)
                    runOnUiThread { details.text = "QR connection failed: ${e.message}. Try a fresh QR." }
                }
            }
        } catch (e: Exception) {
            pairingInProgress.set(false)
            runOnUiThread { details.text = "QR data is invalid: ${e.message}" }
        }
    }

    private fun openVideoSocket() {
        val wsUrl = pcBase.replaceFirst("http://", "ws://") + "/video?token=$token"
        val request = Request.Builder().url(wsUrl).build()
        videoSocket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread {
                    status.text = "Live video connected"
                    details.text = "Streaming ${selectedSize.width}×${selectedSize.height}, requested up to $selectedFps FPS. Actual rate depends on camera support and Wi-Fi."
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { status.text = "Video connection failed: ${t.message}" }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread { status.text = "Video connection closed" }
            }
        })
    }

    private fun rgbaToBitmap(proxy: ImageProxy): Bitmap {
        val plane = proxy.planes.first()
        val source = plane.buffer
        val rowBytes = proxy.width * 4
        val packed = java.nio.ByteBuffer.allocate(rowBytes * proxy.height)
        for (row in 0 until proxy.height) {
            source.position(row * plane.rowStride)
            source.limit(row * plane.rowStride + rowBytes)
            packed.put(source)
        }
        packed.rewind()
        return Bitmap.createBitmap(proxy.width, proxy.height, Bitmap.Config.ARGB_8888).also {
            it.copyPixelsFromBuffer(packed)
        }
    }

    private fun rotateBitmap(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun streamFrame(proxy: ImageProxy) {
        try {
            val now = System.currentTimeMillis()
            if (now - lastFrameAt.get() < (1000L / selectedFps)) return
            val socket = videoSocket ?: return
            if (socket.queueSize() > 512 * 1024) return
            val bitmap = rgbaToBitmap(proxy)
            val rotated = rotateBitmap(bitmap, proxy.imageInfo.rotationDegrees)
            if (rotated !== bitmap) bitmap.recycle()
            val output = ByteArrayOutputStream()
            rotated.compress(Bitmap.CompressFormat.JPEG, 65, output)
            rotated.recycle()
            val bytes = output.toByteArray()
            if (socket.send(ByteString.of(*bytes))) lastFrameAt.set(now)
        } catch (_: Exception) {
            // A dropped frame is preferable to stalling CameraX analysis.
        } finally {
            proxy.close()
        }
    }

    private fun pollForCapture() {
        while (paired.get() && !isFinishing) {
            try {
                val request = Request.Builder().url("$pcBase/next")
                    .header("X-AZU-Token", token).get().build()
                http.newCall(request).execute().use { response ->
                    if (response.code == 401) {
                        paired.set(false)
                        runOnUiThread { status.text = "Pairing expired. Scan the new PC QR code." }
                        return
                    }
                    if (response.isSuccessful && response.body?.string()?.contains("CAPTURE") == true) {
                        takeAndSendPhoto()
                    }
                }
            } catch (_: Exception) {
                Thread.sleep(900)
            }
        }
    }

    private fun takeAndSendPhoto() {
        if (!captureBusy.compareAndSet(false, true)) return
        val target = File(cacheDir, "azu_${System.currentTimeMillis()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(target).build()
        runOnUiThread { status.text = "Capturing photo…" }
        imageCapture?.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                try {
                    val body = target.readBytes().toRequestBody("image/jpeg".toMediaType())
                    val req = Request.Builder().url("$pcBase/photo")
                        .header("X-AZU-Token", token).post(body).build()
                    http.newCall(req).execute().use { response ->
                        if (!response.isSuccessful) throw IllegalStateException("PC upload failed (${response.code})")
                    }
                    runOnUiThread { status.text = "Photo sent to PC successfully" }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Photo transfer failed: ${e.message}" }
                } finally {
                    target.delete()
                    captureBusy.set(false)
                }
            }
            override fun onError(exception: ImageCaptureException) {
                target.delete()
                captureBusy.set(false)
                runOnUiThread { status.text = "Capture failed: ${exception.message}" }
            }
        }) ?: run {
            captureBusy.set(false)
            runOnUiThread { status.text = "Camera is not ready" }
        }
    }

    override fun onDestroy() {
        paired.set(false)
        videoSocket?.close(1000, "App closed")
        scanner.close()
        cameraExecutor.shutdown()
        networkExecutor.shutdownNow()
        http.dispatcher.executorService.shutdown()
        super.onDestroy()
    }
}
