using System.Net;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using QRCoder;

namespace AzuCameraBridge;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

internal sealed class MainForm : Form
{
    private const int Port = 8765;
    private const int MaxFrameBytes = 4 * 1024 * 1024;
    private string token = Convert.ToHexString(RandomNumberGenerator.GetBytes(24));
    private readonly PictureBox qr = new() { Width = 230, Height = 230, SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.White };
    private readonly PictureBox received = new() { Width = 460, Height = 300, SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.FromArgb(28, 35, 43) };
    private readonly Label status = new() { AutoSize = true, Text = "Starting local camera service…" };
    private readonly Label addressLabel = new() { AutoSize = true };
    private readonly Button capture = new() { Text = "Capture photo", AutoSize = true, Enabled = false };
    private readonly Button newQr = new() { Text = "Generate new QR", AutoSize = true };
    private readonly object gate = new();
    private WebApplication? app;
    private volatile bool paired;
    private volatile bool captureRequested;

    public MainForm()
    {
        Text = "AZU Mobile Camera — Live Preview";
        Width = 790; Height = 510; StartPosition = FormStartPosition.CenterScreen;
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(14) };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 270));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        var left = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false };
        left.Controls.Add(new Label { Text = "Scan with AZU Mobile Camera", AutoSize = true, Font = new Font(Font, FontStyle.Bold) });
        left.Controls.Add(qr); left.Controls.Add(addressLabel); left.Controls.Add(status); left.Controls.Add(newQr);
        var right = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false };
        right.Controls.Add(new Label { Text = "Live phone camera preview", AutoSize = true, Font = new Font(Font, FontStyle.Bold) });
        right.Controls.Add(received); right.Controls.Add(capture);
        root.Controls.Add(left, 0, 0); root.Controls.Add(right, 1, 0);
        Controls.Add(root);
        capture.Click += (_, _) => RequestCapture();
        newQr.Click += (_, _) => RegeneratePairing();
        Shown += async (_, _) => await StartServerAsync();
        FormClosing += async (_, _) => { if (app is not null) await app.StopAsync(); };
    }

    private string GetLanIp()
    {
        foreach (var nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
        {
            if (nic.OperationalStatus != System.Net.NetworkInformation.OperationalStatus.Up) continue;
            foreach (var ua in nic.GetIPProperties().UnicastAddresses)
            {
                var ip = ua.Address;
                if (ip.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork || IPAddress.IsLoopback(ip))
                    continue;
                var b = ip.GetAddressBytes();
                if (b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) ||
                    (b[0] == 192 && b[1] == 168))
                    return ip.ToString();
            }
        }
        return "127.0.0.1";
    }

    private void RegeneratePairing()
    {
        token = Convert.ToHexString(RandomNumberGenerator.GetBytes(24));
        paired = false;
        captureRequested = false;
        var ip = GetLanIp();
        var payload = JsonSerializer.Serialize(new { url = $"http://{ip}:{Port}", token });
        using var generator = new QRCodeGenerator();
        using var data = generator.CreateQrCode(payload, QRCodeGenerator.ECCLevel.Q);
        var png = new PngByteQRCode(data).GetGraphic(8);
        using var stream = new MemoryStream(png);
        qr.Image?.Dispose();
        qr.Image = Image.FromStream(stream);
        addressLabel.Text = $"PC: http://{ip}:{Port}";
        status.Text = "Waiting for phone to scan QR…";
        capture.Enabled = false;
        received.Image?.Dispose();
        received.Image = null;
    }

    private async Task StartServerAsync()
    {
        try
        {
            RegeneratePairing();
            var builder = WebApplication.CreateBuilder();
            builder.WebHost.UseUrls($"http://0.0.0.0:{Port}");
            app = builder.Build();
            app.UseWebSockets(new WebSocketOptions { KeepAliveInterval = TimeSpan.FromSeconds(20) });

            app.MapPost("/pair", async (HttpContext ctx) =>
            {
                using var doc = await JsonDocument.ParseAsync(ctx.Request.Body);
                var supplied = doc.RootElement.GetProperty("token").GetString();
                if (!FixedEquals(supplied, token)) return Results.Unauthorized();
                paired = true;
                BeginInvoke(() => { status.Text = "Phone paired — waiting for video"; capture.Enabled = true; });
                return Results.Ok(new { paired = true });
            });

            app.Map("/video", async ctx =>
            {
                if (!ctx.WebSockets.IsWebSocketRequest || !paired ||
                    !FixedEquals(ctx.Request.Query["token"].FirstOrDefault(), token))
                {
                    ctx.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    return;
                }

                using var socket = await ctx.WebSockets.AcceptWebSocketAsync();
                var buffer = new byte[64 * 1024];
                using var frame = new MemoryStream();
                try
                {
                    while (socket.State == WebSocketState.Open && paired)
                    {
                        frame.SetLength(0);
                        WebSocketReceiveResult result;
                        do
                        {
                            result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), ctx.RequestAborted);
                            if (result.MessageType == WebSocketMessageType.Close)
                            {
                                await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closed", CancellationToken.None);
                                return;
                            }
                            if (result.MessageType != WebSocketMessageType.Binary)
                            {
                                await socket.CloseAsync(WebSocketCloseStatus.InvalidMessageType, "Binary JPEG frames required", CancellationToken.None);
                                return;
                            }
                            if (frame.Length + result.Count > MaxFrameBytes)
                            {
                                await socket.CloseAsync(WebSocketCloseStatus.MessageTooBig, "Frame too large", CancellationToken.None);
                                return;
                            }
                            frame.Write(buffer, 0, result.Count);
                        } while (!result.EndOfMessage);

                        var bytes = frame.ToArray();
                        if (bytes.Length > 4 && bytes[0] == 0xFF && bytes[1] == 0xD8)
                            BeginInvoke(() => ShowLiveFrame(bytes));
                    }
                }
                catch (OperationCanceledException) { }
                catch (WebSocketException) { }
            });

            app.MapGet("/next", (HttpContext ctx) =>
            {
                if (!Authorized(ctx)) return Results.Unauthorized();
                lock (gate)
                {
                    if (captureRequested)
                    {
                        captureRequested = false;
                        return Results.Text("CAPTURE", "text/plain");
                    }
                }
                return Results.Text("WAIT", "text/plain");
            });

            app.MapPost("/photo", async (HttpContext ctx) =>
            {
                if (!Authorized(ctx)) return Results.Unauthorized();
                if (ctx.Request.ContentLength is > 20_000_000) return Results.BadRequest("Photo too large");
                using var ms = new MemoryStream();
                await ctx.Request.Body.CopyToAsync(ms);
                var bytes = ms.ToArray();
                if (bytes.Length < 4 || bytes[0] != 0xFF || bytes[1] != 0xD8) return Results.BadRequest("Expected JPEG");
                BeginInvoke(() => ShowPhoto(bytes));
                return Results.Ok(new { received = bytes.Length });
            });

            await app.StartAsync();
            status.Text = "Waiting for phone to scan QR…";
        }
        catch (Exception ex)
        {
            status.Text = "Server error: " + ex.Message;
            MessageBox.Show(this, ex.ToString(), "AZU Camera Bridge", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private bool Authorized(HttpContext ctx)
    {
        var supplied = ctx.Request.Headers["X-AZU-Token"].FirstOrDefault();
        return paired && FixedEquals(supplied, token);
    }

    private static bool FixedEquals(string? a, string b)
    {
        if (a is null) return false;
        return CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(a), Encoding.UTF8.GetBytes(b));
    }

    private void RequestCapture()
    {
        if (!paired) return;
        lock (gate) captureRequested = true;
        status.Text = "Capture requested — waiting for phone…";
    }

    private void ShowLiveFrame(byte[] bytes)
    {
        try
        {
            using var ms = new MemoryStream(bytes);
            using var temp = Image.FromStream(ms);
            var next = new Bitmap(temp);
            var old = received.Image;
            received.Image = next;
            old?.Dispose();
            status.Text = $"Live video — {DateTime.Now:HH:mm:ss}";
        }
        catch (Exception) { /* Ignore a malformed or incomplete frame. */ }
    }

    private void ShowPhoto(byte[] bytes)
    {
        using var ms = new MemoryStream(bytes);
        using var temp = Image.FromStream(ms);
        received.Image?.Dispose();
        received.Image = new Bitmap(temp);
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "AZU Mobile Camera");
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, $"AZU_{DateTime.Now:yyyyMMdd_HHmmss_fff}.jpg");
        File.WriteAllBytes(path, bytes);
        status.Text = $"Photo received and saved: {path}";
    }
}
