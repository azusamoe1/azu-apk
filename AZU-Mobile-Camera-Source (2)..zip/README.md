# AZU Mobile Camera — QR pairing prototype

## Architecture
- Windows AZU Camera Bridge hosts the local Wi-Fi API and displays a fresh QR code.
- Android AZU Mobile Camera scans the QR with the phone camera.
- After pairing, the Android app polls the PC for capture requests and sends captured JPEGs back.
- This prototype supports PC-requested still-photo transfer. It does **not yet** implement a Windows virtual webcam device or continuous live video.

## Android build without Android Studio
Use the repository GitHub Actions workflow to build `android/app/build/outputs/apk/debug/app-debug.apk`.
Requires JDK 17 and Gradle 8.9. The GitHub workflow should unzip this archive into `source/`, then run Gradle with `-p source/android`.

## Android usage
1. Launch the APK and grant camera permission.
2. Point the phone at the QR code shown by the Windows bridge.
3. Keep the app open in the foreground while paired.
4. Click Capture photo on Windows. The phone captures with CameraX and returns the JPEG.

## Windows build
Install .NET 8 SDK on Windows and run:
`dotnet run --project windows/AzuCameraBridge`

The Windows bridge targets x86. It can run on 32-bit Windows and under WOW64 on 64-bit Windows. For a 64-bit-only native deployment, build separately for x64.

## Network and security
Both devices must be on the same trusted Wi-Fi network. Allow the Windows app through Windows Firewall on private networks only. Pairing token is regenerated each time the Windows bridge starts. Do not expose this prototype API to the public internet.
