package com.azu.mobilecamera

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Size
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.mlkit.vision.MlKitAnalyzer
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var details: TextView
    private var imageCapture: ImageCapture? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val networkExecutor = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS).readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS).build()
    private val paired = AtomicBoolean(false)
    private val captureBusy = AtomicBoolean(false)
    @Volatile private var pcBase = ""
    @Volatile private var token = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        status = findViewById(R.id.status)
        details = findViewById(R.id.details)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 100)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else status.text = "Camera permission is required."
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            val scanner = BarcodeScanning.getClient()
            val analysis = ImageAnalysis.Builder().setTargetResolution(Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(cameraExecutor, MlKitAnalyzer(
                listOf(scanner), ImageAnalysis.COORDINATE_SYSTEM_ORIGINAL, cameraExecutor
            ) { result ->
                if (paired.get()) return@MlKitAnalyzer
                val barcode = result?.getValue(scanner)?.firstOrNull {
                    it.format == Barcode.FORMAT_QR_CODE && !it.rawValue.isNullOrBlank()
                }
                barcode?.rawValue?.let { acceptQr(it) }
            })
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA,
                    previewUseCase, imageCapture, analysis)
                status.text = "Scan the dynamic QR code on your PC"
            } catch (e: Exception) {
                status.text = "Camera error: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @Synchronized private fun acceptQr(raw: String) {
        if (paired.get()) return
        try {
            val data = JSONObject(raw)
            val base = data.getString("url").trimEnd('/')
            val key = data.getString("token")
            require(base.startsWith("http://") && key.isNotBlank())
            pcBase = base
            token = key
            val request = Request.Builder().url("$base/pair")
                .post(JSONObject().put("token", key).put("device", android.os.Build.MODEL)
                    .toString().toRequestBody("application/json".toMediaType())).build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IllegalStateException("PC rejected pairing (${response.code})")
            }
            paired.set(true)
            runOnUiThread {
                status.text = "Connected to AZU Camera Bridge"
                details.text = "Phone paired. Keep AZU Mobile Camera open; use Capture photo on your PC."
            }
            networkExecutor.execute { pollForCapture() }
        } catch (e: Exception) {
            runOnUiThread { details.text = "QR connection failed: ${e.message}. Try a fresh QR." }
        }
    }

    private fun pollForCapture() {
        while (paired.get() && !isFinishing) {
            try {
                val request = Request.Builder().url("$pcBase/next")
                    .header("X-AZU-Token", token).get().build()
                http.newCall(request).execute().use { response ->
                    if (response.code == 401) {
                        paired.set(false)
                        runOnUiThread { status.text = "Pairing expired. Scan the new PC QR code." }
                        return
                    }
                    if (response.isSuccessful && response.body?.string()?.contains("CAPTURE") == true) {
                        takeAndSendPhoto()
                    }
                }
            } catch (_: Exception) {
                Thread.sleep(900)
            }
        }
    }

    private fun takeAndSendPhoto() {
        if (!captureBusy.compareAndSet(false, true)) return
        val target = File(cacheDir, "azu_${System.currentTimeMillis()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(target).build()
        runOnUiThread { status.text = "Capturing photo…" }
        imageCapture?.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                try {
                    val body = target.readBytes().toRequestBody("image/jpeg".toMediaType())
                    val req = Request.Builder().url("$pcBase/photo")
                        .header("X-AZU-Token", token).post(body).build()
                    http.newCall(req).execute().use { response ->
                        if (!response.isSuccessful) throw IllegalStateException("PC upload failed (${response.code})")
                    }
                    runOnUiThread { status.text = "Photo sent to PC successfully" }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Photo transfer failed: ${e.message}" }
                } finally {
                    target.delete()
                    captureBusy.set(false)
                }
            }
            override fun onError(exception: ImageCaptureException) {
                target.delete()
                captureBusy.set(false)
                runOnUiThread { status.text = "Capture failed: ${exception.message}" }
            }
        }) ?: run {
            captureBusy.set(false)
            runOnUiThread { status.text = "Camera is not ready" }
        }
    }

    override fun onDestroy() {
        paired.set(false)
        cameraExecutor.shutdown()
        networkExecutor.shutdownNow()
        http.dispatcher.executorService.shutdown()
        super.onDestroy()
    }
}
