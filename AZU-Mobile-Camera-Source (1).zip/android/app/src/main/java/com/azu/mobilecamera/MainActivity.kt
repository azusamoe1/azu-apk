package com.azu.mobilecamera

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import fi.iki.elonen.NanoHTTPD
import java.io.ByteArrayOutputStream
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.Base64
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var pairing: TextView
    private var capture: ImageCapture? = null
    private var server: CaptureServer? = null
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val token: String = ByteArray(18).also { SecureRandom().nextBytes(it) }
        .let { Base64.getUrlEncoder().withoutPadding().encodeToString(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        status = findViewById(R.id.status)
        pairing = findViewById(R.id.pairing)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else status.text = "Camera permission is required."
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val p = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            capture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, p, capture)
                startServer()
            } catch (e: Exception) { status.text = "Camera error: ${e.message}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startServer() {
        try {
            server = CaptureServer(8765, token) { done ->
                val imageCapture = capture ?: run { done(null); return@CaptureServer }
                val tempFile = java.io.File(cacheDir, "azu_capture_${System.currentTimeMillis()}.jpg")
                val options = ImageCapture.OutputFileOptions.Builder(tempFile).build()
                imageCapture.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                        val data = try { tempFile.readBytes() } catch (_: Exception) { null }
                        tempFile.delete()
                        done(data)
                    }
                    override fun onError(exception: ImageCaptureException) { tempFile.delete(); done(null) }
                })
            }
            server?.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            val ip = localIp()
            status.text = "Camera ready — keep this screen open"
            pairing.text = "PC address: http://$ip:8765
Pairing token: $token"
        } catch (e: Exception) { status.text = "Local server error: ${e.message}" }
    }

    private fun localIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .first { !it.isLoopbackAddress && it.hostAddress?.contains(':') == false }.hostAddress ?: "Find phone IP in Wi-Fi settings"
    } catch (_: Exception) { "Find phone IP in Wi-Fi settings" }

    override fun onDestroy() {
        server?.stop()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}

private class CaptureServer(
    port: Int, private val token: String, private val takePhoto: ((ByteArray?) -> Unit) -> Unit
) : NanoHTTPD(port) {
    override fun serve(session: IHTTPSession): Response {
        if (session.method == Method.GET && session.uri == "/health")
            return newFixedLengthResponse(Response.Status.OK, "text/plain", "AZU camera ready")
        if (session.method == Method.POST && session.uri == "/capture") {
            if (session.headers["x-azu-token"] != token)
                return newFixedLengthResponse(Response.Status.UNAUTHORIZED, "text/plain", "Unauthorized")
            val latch = java.util.concurrent.CountDownLatch(1)
            var bytes: ByteArray? = null
            takePhoto { bytes = it; latch.countDown() }
            if (!latch.await(20, java.util.concurrent.TimeUnit.SECONDS))
                return newFixedLengthResponse(Response.Status.REQUEST_TIMEOUT, "text/plain", "Capture timeout")
            val data = bytes ?: return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "Capture failed")
            return newFixedLengthResponse(Response.Status.OK, "image/jpeg", data.inputStream(), data.size.toLong())
        }
        return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
    }
}
