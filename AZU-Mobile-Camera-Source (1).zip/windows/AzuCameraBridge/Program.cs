using System.Net.Http;
using System.Net.Http.Headers;

namespace AzuCameraBridge;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

internal sealed class MainForm : Form
{
    private readonly TextBox address = new() { Width = 260, Text = "http://192.168.1.100:8765" };
    private readonly TextBox token = new() { Width = 260, UseSystemPasswordChar = true };
    private readonly Button capture = new() { Text = "Capture photo", AutoSize = true };
    private readonly Label status = new() { AutoSize = true, Text = "Enter the phone address and pairing token." };
    private readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(25) };

    public MainForm()
    {
        Text = "AZU Camera Bridge — prototype";
        Width = 520; Height = 230; StartPosition = FormStartPosition.CenterScreen;
        var layout = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(16), FlowDirection = FlowDirection.TopDown, WrapContents = false };
        layout.Controls.Add(new Label { Text = "Android phone address", AutoSize = true }); layout.Controls.Add(address);
        layout.Controls.Add(new Label { Text = "Pairing token", AutoSize = true }); layout.Controls.Add(token);
        layout.Controls.Add(capture); layout.Controls.Add(status);
        Controls.Add(layout);
        capture.Click += async (_, _) => await CaptureAsync();
    }

    private async Task CaptureAsync()
    {
        capture.Enabled = false;
        try
        {
            var url = address.Text.Trim().TrimEnd('/') + "/capture";
            using var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Add("X-AZU-Token", token.Text.Trim());
            using var response = await http.SendAsync(request);
            response.EnsureSuccessStatusCode();
            var bytes = await response.Content.ReadAsByteArrayAsync();
            var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "AZU Mobile Camera");
            Directory.CreateDirectory(folder);
            var path = Path.Combine(folder, $"AZU_{DateTime.Now:yyyyMMdd_HHmmss_fff}.jpg");
            await File.WriteAllBytesAsync(path, bytes);
            status.Text = $"Saved: {path}";
        }
        catch (Exception ex) { status.Text = "Error: " + ex.Message; }
        finally { capture.Enabled = true; }
    }
}
